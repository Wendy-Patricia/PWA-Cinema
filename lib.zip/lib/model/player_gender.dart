enum PlayerGender {
  homme,
  femme,
}